
window.CONFIG = {
    CONNECT_ON_PAGE_LOAD: false,
};